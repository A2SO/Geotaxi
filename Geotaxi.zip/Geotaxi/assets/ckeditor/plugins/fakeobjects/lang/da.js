﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'da', {
	anchor: 'Anker',
	flash: 'Flashanimation',
	hiddenfield: 'Skjult felt',
	iframe: 'Iframe',
	unknown: 'Ukendt objekt'
} );
